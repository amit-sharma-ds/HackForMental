let tabTimes = {};
let lastPointTime = 0;

chrome.tabs.onActivated.addListener(activeInfo => {
  const tabId = activeInfo.tabId;
  chrome.tabs.get(tabId, tab => {
    if (tab.url && isSocialMedia(tab.url)) {
      startTracking(tabId);
    }
  });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && isSocialMedia(tab.url)) {
    startTracking(tabId);
  }
});

chrome.tabs.onRemoved.addListener(tabId => {
  delete tabTimes[tabId];
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "endSession") {
    if (message.wasMindful) {
      const today = new Date().toISOString().split('T')[0];
      chrome.storage.local.get(['astraDailyPoints'], result => {
        const data = result.astraDailyPoints || {};
        data[today] = (data[today] || 0) + 1;
        chrome.storage.local.set({ astraDailyPoints: data }, () => {
          sendResponse(); // wait for point saved
        });
      });
      return true; // async response
    } else {
      sendResponse();
    }
    endSession(sender.tab.id);
  }

  if (message.action === "closeTab") {
    if (sender.tab && sender.tab.id) {
      chrome.tabs.remove(sender.tab.id);
    }
  }
});

function isSocialMedia(url) {
  return url.includes("facebook.com") || url.includes("twitter.com") || url.includes("instagram.com");
}

function startTracking(tabId) {
  if (!tabTimes[tabId]) {
    tabTimes[tabId] = Date.now();
    checkTime(tabId);
  }
}

function checkTime(tabId) {
  const start = tabTimes[tabId];
  if (!start) return;

  chrome.storage.local.get(['astraTime'], result => {
    const limit = result.astraTime || 20000;
    const elapsed = Date.now() - start;

    if (elapsed >= limit) {
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ["content.js"]
      });
    } else {
      setTimeout(() => checkTime(tabId), 1000);
    }
  });
}

function endSession(tabId) {
  if (tabTimes[tabId]) {
    delete tabTimes[tabId];
  }
}
