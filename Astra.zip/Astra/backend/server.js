const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

app.post('/get-ai-message', async (req, res) => {
  try {
    const prompt = "Give me a short mindful, motivational message in less than 15 words.";
    const response = await axios.post(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent',
      {
        contents: [{ parts: [{ text: prompt }] }]
      },
      {
        params: { key: process.env.GEMINI_API_KEY }
      }
    );

    const aiText = response.data.candidates?.[0]?.content?.parts?.[0]?.text;
    res.json({ message: aiText || "Take a breath and be present." });
  } catch (err) {
    console.error("Gemini API Error:", err.response?.data || err.message);
    res.status(500).json({ message: "Take a breath and be present." });
  }
});

app.listen(3000, () => console.log("✅ Server running on http://localhost:3000"));
