document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.local.get(['reflectifyTime'], (result) => {
        const ms = result.reflectifyTime || 20000;
        const totalSeconds = Math.floor(ms / 1000);
        const hrs = Math.floor(totalSeconds / 3600);
        const mins = Math.floor((totalSeconds % 3600) / 60);
        const secs = totalSeconds % 60;

        document.getElementById('hours').value = hrs;
        document.getElementById('minutes').value = mins;
        document.getElementById('seconds').value = secs;
    });
});

document.getElementById('saveBtn').addEventListener('click', () => {
    const hrs = parseInt(document.getElementById('hours').value) || 0;
    const mins = parseInt(document.getElementById('minutes').value) || 0;
    const secs = parseInt(document.getElementById('seconds').value) || 0;

    const totalMs = ((hrs * 3600) + (mins * 60) + secs) * 1000;

    if (totalMs <= 0) {
        alert("Please enter a valid time greater than 0.");
        return;
    }

    chrome.storage.local.set({ reflectifyTime: totalMs }, () => {
        document.getElementById('status').textContent = 
            `Saved: ${hrs}h ${mins}m ${secs}s`;
    });
});

document.getElementById('openDashboard').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
});
