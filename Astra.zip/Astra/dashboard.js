chrome.storage.local.get(['astraDailyPoints'], result => {
  const data = result.astraDailyPoints || {};
  const sortedKeys = Object.keys(data).sort();
  const labels = sortedKeys;
  const values = sortedKeys.map(key => data[key]);

  // Update the points text with today's points or 0
  const today = new Date().toISOString().split('T')[0];
  const todayPoints = data[today] || 0;
  document.getElementById('points').textContent = `${todayPoints} Mindful Points Today`;

  if (labels.length > 0) {
    const ctx = document.getElementById('trendChart').getContext('2d');
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Mindful Points per Day',
          data: values,
          fill: false,
          borderColor: 'rgb(75, 192, 192)',
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: { beginAtZero: true }
        }
      }
    });
  } else {
    document.getElementById('points').textContent = "No data yet.";
  }
});

document.getElementById('closeTabBtn').addEventListener('click', () => {
  window.close();
});
