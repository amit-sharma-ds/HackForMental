const blurWrapper = document.createElement('div');
blurWrapper.id = 'astra-blur-wrapper';
while (document.body.firstChild) {
  blurWrapper.appendChild(document.body.firstChild);
}
document.body.appendChild(blurWrapper);
blurWrapper.style.filter = "blur(5px)";

const overlay = document.createElement('div');
overlay.id = 'astra-overlay';
overlay.style.cssText = `
  position: fixed;
  top: 0; left: 0;
  width: 100%; height: 100%;
  background-color: rgba(0, 0, 0, 0.85);
  color: white;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  z-index: 999999;
  font-family: Arial, sans-serif;
  text-align: center;
  padding: 20px;
`;

async function getAIMessage() {
  try {
    const res = await fetch("http://localhost:3000/get-ai-message", {
      method: "POST"
    });
    const data = await res.json();
    return data.message;
  } catch (e) {
    console.error("AI fetch failed", e);
    return "Take a breath and be present.";
  }
}

getAIMessage().then(message => {
  overlay.innerHTML = `
    <h1 style="font-size: 40px; margin-bottom: 30px; color: white;">${message}</h1>
    <div style="display: flex; gap: 20px;">
      <button id="astra-continue" style="
        font-size: 20px;
        padding: 12px 25px;
        background-color: #4CAF50;
        border: none;
        border-radius: 8px;
        color: white;
        cursor: pointer;
      ">Continue</button>

      <button id="astra-close" style="
        font-size: 20px;
        padding: 12px 25px;
        background-color: #f44336;
        border: none;
        border-radius: 8px;
        color: white;
        cursor: pointer;
      ">Close Tab</button>
    </div>
  `;

  document.body.appendChild(overlay);

  document.getElementById('astra-continue').onclick = () => {
    blurWrapper.style.filter = "";
    overlay.remove();
    chrome.runtime.sendMessage({ action: "endSession", wasMindful: false });
  };

  document.getElementById('astra-close').onclick = () => {
    chrome.runtime.sendMessage({ action: "endSession", wasMindful: true }, () => {
      chrome.runtime.sendMessage({ action: "closeTab" });
    });
  };
});
