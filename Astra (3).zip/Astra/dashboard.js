chrome.storage.local.get(['astraDailyPoints'], result => {
    const data = result.astraDailyPoints || {};
    const sortedKeys = Object.keys(data).sort();
    const labels = sortedKeys;
    const values = sortedKeys.map(key => data[key]);

    const ctx = document.getElementById('trendChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Mindful Points per Day',
                data: values,
                fill: false,
                borderColor: 'rgb(75, 192, 192)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
});

// Close dashboard tab
document.getElementById('closeTabBtn').addEventListener('click', () => {
    window.close();
});
